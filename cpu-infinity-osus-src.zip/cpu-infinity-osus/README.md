# CPU Infinity Osus

Rust (libinfinity_osus.so, aarch64-linux-android, NEON) + Fabric mod for low-end ARM64 Android (Fold Craft Launcher).

## Tree
```
cpu-infinity-osus/
├─ build-native.sh
├─ build.gradle  settings.gradle  gradle.properties
├─ rust/
│  ├─ Cargo.toml
│  └─ src/lib.rs
└─ src/main/
   ├─ java/io/infinityosus/
   │  ├─ OsusLog.java  OsusPreLaunch.java  OsusClient.java
   │  ├─ natives/   NativeLoader.java  OsusNative.java
   │  ├─ runtime/   OsusRuntime.java  OsusKernels.java  OsusStats.java
   │  │             OsusHud.java  OsusCommands.java  LongSlotMap.java
   │  ├─ mixin/     MinecraftMixin  EntityRenderDispatcherMixin  ClientLevelMixin
   │  │             BoundTickingBlockEntityMixin  GuiMixin
   │  └─ plugin/    OsusMixinPlugin.java
   └─ resources/
      ├─ fabric.mod.json  infinity-osus.mixins.json
      └─ natives/android-arm64/libinfinity_osus.so   <- produced by build-native.sh
```

## Build
```
rustup target add aarch64-linux-android
cargo install cargo-ndk
export ANDROID_NDK_HOME=$HOME/Android/Sdk/ndk/<version>

cd rust
cargo ndk -t arm64-v8a build --release
mkdir -p ../src/main/resources/natives/android-arm64
cp target/aarch64-linux-android/release/libinfinity_osus.so ../src/main/resources/natives/android-arm64/
cd ..

gradle wrapper --gradle-version 8.10.2     # once
./gradlew build
```
(`./build-native.sh` does the cargo part.) Jar: `build/libs/cpu-infinity-osus-1.0.0.jar` -> drop in the FCL `mods` folder.

## Flags
-Dosus.disable=true  |  -Dosus.fovScale=1.35  |  -Dosus.fovPad=6
