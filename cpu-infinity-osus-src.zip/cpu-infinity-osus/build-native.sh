#!/usr/bin/env bash
# Builds libinfinity_osus.so for arm64-v8a and drops it where the jar packs it from.
set -euo pipefail
cd "$(dirname "$0")/rust"
rustup target add aarch64-linux-android
command -v cargo-ndk >/dev/null || cargo install cargo-ndk
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to your NDK dir (r26+)}"
cargo ndk -t arm64-v8a build --release
mkdir -p ../src/main/resources/natives/android-arm64
cp target/aarch64-linux-android/release/libinfinity_osus.so ../src/main/resources/natives/android-arm64/libinfinity_osus.so
echo "OK -> src/main/resources/natives/android-arm64/libinfinity_osus.so"
