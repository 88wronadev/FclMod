package io.infinityosus.plugin;

import io.infinityosus.OsusLog;
import io.infinityosus.natives.NativeLoader;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;

/**
 * Gates every mixin on "native core actually loaded". If the .so failed to load (x86 desktop,
 * noexec storage, -Dosus.disable=true) no mixin is applied and the game runs fully vanilla.
 * All injectors are require=0, so a signature that differs on a given Minecraft version is
 * skipped instead of crashing.
 */
public final class OsusMixinPlugin implements IMixinConfigPlugin {
    private boolean enabled;

    @Override
    public void onLoad(String mixinPackage) {
        String mc = FabricLoader.getInstance().getModContainer("minecraft")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");
        enabled = !Boolean.getBoolean("osus.disable") && NativeLoader.isLoaded();
        OsusLog.info("mixin plugin: Minecraft " + mc + ", Java " + System.getProperty("java.version")
                + ", mixins " + (enabled ? "ENABLED" : "DISABLED (" + NativeLoader.failure() + ")"));
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        return enabled;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
}
