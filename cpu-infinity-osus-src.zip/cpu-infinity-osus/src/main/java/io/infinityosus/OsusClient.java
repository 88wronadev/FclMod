package io.infinityosus;

import io.infinityosus.runtime.OsusCommands;
import net.fabricmc.api.ClientModInitializer;

public final class OsusClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        try {
            OsusCommands.register();
        } catch (Throwable t) {
            OsusLog.warn("command registration failed safely: " + t);
        }
    }
}
