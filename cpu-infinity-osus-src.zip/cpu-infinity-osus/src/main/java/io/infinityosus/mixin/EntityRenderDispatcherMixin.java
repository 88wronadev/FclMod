package io.infinityosus.mixin;

import io.infinityosus.runtime.OsusRuntime;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    /** Entity visibility comes from the Rust NEON Precision pass (zero-copy DirectByteBuffer). */
    @Inject(
            method = "shouldRender(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z",
            at = @At("HEAD"),
            cancellable = true,
            require = 0)
    private void osus$neonCull(Entity entity, Frustum frustum, double camX, double camY, double camZ,
                               CallbackInfoReturnable<Boolean> cir) {
        if (OsusRuntime.isEntityCulled(entity)) {
            cir.setReturnValue(false);
        }
    }
}
