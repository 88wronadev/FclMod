package io.infinityosus.mixin;

import io.infinityosus.runtime.OsusRuntime;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientLevel.class)
public abstract class ClientLevelMixin {
    /** Client-side visual tick only; the (integrated) server copy of the entity is never touched. */
    @Inject(method = "tickNonPassenger(Lnet/minecraft/world/entity/Entity;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void osus$throttleEntityTick(Entity entity, CallbackInfo ci) {
        if (OsusRuntime.shouldSkipEntityTick(entity)) {
            ci.cancel();
        }
    }
}
