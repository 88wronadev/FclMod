package io.infinityosus.mixin;

import io.infinityosus.runtime.OsusRuntime;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity")
public abstract class BoundTickingBlockEntityMixin {
    @Shadow
    private BlockEntity blockEntity;

    /** Runtime guards to the client level only, so server-side campfire cooking etc. is never throttled. */
    @Inject(method = "tick()V", at = @At("HEAD"), cancellable = true, require = 0)
    private void osus$throttleBlockEntityTick(CallbackInfo ci) {
        if (this.blockEntity != null && OsusRuntime.shouldSkipBlockEntityTick(this.blockEntity)) {
            ci.cancel();
        }
    }
}
