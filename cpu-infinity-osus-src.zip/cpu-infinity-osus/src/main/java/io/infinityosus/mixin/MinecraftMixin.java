package io.infinityosus.mixin;

import io.infinityosus.runtime.OsusRuntime;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    /** Frame boundary: feeds the Smart-thread governor and rotates the per-frame culling batch. */
    @Inject(method = "runTick(Z)V", at = @At("HEAD"), require = 0)
    private void osus$beginFrame(boolean renderLevel, CallbackInfo ci) {
        OsusRuntime.beginFrame();
    }
}
