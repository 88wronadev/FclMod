package io.infinityosus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class OsusLog {
    private static final Logger LOG = LoggerFactory.getLogger("InfinityOsus");

    private OsusLog() {}

    public static void info(String msg) {
        LOG.info("[Osus] {}", msg);
    }

    public static void warn(String msg) {
        LOG.warn("[Osus] {}", msg);
    }

    public static void error(String msg, Throwable t) {
        LOG.error("[Osus] " + msg, t);
    }
}
