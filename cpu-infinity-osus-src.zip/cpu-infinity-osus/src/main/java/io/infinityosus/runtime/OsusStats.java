package io.infinityosus.runtime;

import io.infinityosus.natives.NativeLoader;
import io.infinityosus.natives.OsusNative;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.LongAdder;

/** Counters plus the text shown by /osus stats and the overlay. */
public final class OsusStats {
    public static final LongAdder entitiesCulled = new LongAdder();
    public static final LongAdder entityTicksThrottled = new LongAdder();
    public static final LongAdder blockEntityTicksThrottled = new LongAdder();
    public static final LongAdder beBatches = new LongAdder();

    public static volatile boolean overlay;
    static volatile int lastBatchCount;
    static volatile int lastBatchVisible;
    static volatile long lastCullNanos;

    /** Estimated per-item costs on a Mali-G57 class device. These are estimates, not measurements. */
    private static final double EST_MS_PER_CULLED_ENTITY = 0.015;
    private static final double EST_MS_PER_ENTITY_TICK = 0.020;
    private static final double EST_MS_PER_BE_TICK = 0.010;

    private static final String[] NAMES = {"Performance", "Fast", "Precision", "Smart", "Efficiency", "Osus"};
    private static final String[] COLORS = {"\u00a7a", "\u00a7b", "\u00a7d", "\u00a7e", "\u00a76", "\u00a79"};

    private static long rateTs;
    private static long rateEnt;
    private static long rateBe;
    private static double entPerSec;
    private static double bePerSec;

    private OsusStats() {}

    private static void sampleRates() {
        long now = System.nanoTime();
        if (rateTs == 0L) {
            rateTs = now;
            rateEnt = entityTicksThrottled.sum();
            rateBe = blockEntityTicksThrottled.sum();
            return;
        }
        long dt = now - rateTs;
        if (dt >= 500_000_000L) {
            long e = entityTicksThrottled.sum();
            long b = blockEntityTicksThrottled.sum();
            entPerSec = (e - rateEnt) * 1e9 / dt;
            bePerSec = (b - rateBe) * 1e9 / dt;
            rateEnt = e;
            rateBe = b;
            rateTs = now;
        }
    }

    public static synchronized List<String> lines(boolean color) {
        List<String> out = new ArrayList<>();
        String w = color ? "\u00a7f" : "";
        String g = color ? "\u00a77" : "";
        if (!NativeLoader.isLoaded()) {
            out.add(w + "Infinity Osus: native core NOT loaded");
            out.add(g + NativeLoader.failure());
            return out;
        }
        if (!OsusRuntime.isActive()) {
            out.add(w + "Infinity Osus: loaded, runtime passive (circuit breaker or waiting for first frame)");
            return out;
        }
        long[] s = new long[32];
        OsusNative.nativeGetStats(s);
        sampleRates();

        out.add(w + String.format(Locale.ROOT, "Infinity Osus | NEON %s | workers %d (burst +%d)",
                s[29] == 1 ? "ON" : "scalar", s[22], s[20]));
        for (int i = 0; i < 6; i++) {
            String name = color ? COLORS[i] + NAMES[i] : NAMES[i];
            out.add(String.format(Locale.ROOT, "%s%s %s%5.1f%%  %d thr  %d tasks",
                    name, " ".repeat(Math.max(1, 12 - NAMES[i].length())), w, s[i] / 10.0, s[12 + i], s[6 + i]));
        }
        out.add(w + String.format(Locale.ROOT, "NEON culled: frame %d/%d | session %d/%d",
                lastBatchCount - lastBatchVisible, lastBatchCount, s[19], s[18]));
        out.add(w + String.format(Locale.ROOT, "Burst: %s | events %d | governor steps %d",
                s[20] > 0 ? "ACTIVE" : "idle", s[21], s[28]));
        double ema = s[23] / 1000.0;
        out.add(w + String.format(Locale.ROOT, "Frame EMA %.2f ms | target %.1f ms | cull call %d us",
                ema, s[24] / 1000.0, lastCullNanos / 1000L));
        out.add(w + String.format(Locale.ROOT, "Throttled/s: entities %.0f | block-entities %.0f",
                entPerSec, bePerSec));
        double renderSaved = (lastBatchCount - lastBatchVisible) * EST_MS_PER_CULLED_ENTITY - lastCullNanos / 1e6;
        double fps = ema > 0.1 ? 1000.0 / ema : 0.0;
        double tickSaved = fps > 0.0
                ? (entPerSec * EST_MS_PER_ENTITY_TICK + bePerSec * EST_MS_PER_BE_TICK) / fps
                : 0.0;
        out.add(w + String.format(Locale.ROOT, "Est. savings/frame: render %+.2f ms + ticks %.2f ms = %+.2f ms",
                renderSaved, tickSaved, renderSaved + tickSaved));
        return out;
    }
}
