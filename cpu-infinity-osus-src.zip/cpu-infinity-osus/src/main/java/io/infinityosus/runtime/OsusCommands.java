package io.infinityosus.runtime;

import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

/** /osus stats, /osus overlay [on|off]. */
public final class OsusCommands {
    private OsusCommands() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("osus")
                        .executes(ctx -> help(ctx.getSource()))
                        .then(ClientCommandManager.literal("stats")
                                .executes(ctx -> stats(ctx.getSource())))
                        .then(ClientCommandManager.literal("overlay")
                                .executes(ctx -> setOverlay(ctx.getSource(), !OsusStats.overlay))
                                .then(ClientCommandManager.literal("on")
                                        .executes(ctx -> setOverlay(ctx.getSource(), true)))
                                .then(ClientCommandManager.literal("off")
                                        .executes(ctx -> setOverlay(ctx.getSource(), false))))));
    }

    private static int help(FabricClientCommandSource src) {
        src.sendFeedback(Component.literal("/osus stats  |  /osus overlay [on|off]"));
        return 1;
    }

    private static int stats(FabricClientCommandSource src) {
        for (String line : OsusStats.lines(true)) {
            src.sendFeedback(Component.literal(line));
        }
        return 1;
    }

    private static int setOverlay(FabricClientCommandSource src, boolean on) {
        OsusStats.overlay = on;
        src.sendFeedback(Component.literal("Osus overlay " + (on ? "ON" : "OFF")));
        return 1;
    }
}
