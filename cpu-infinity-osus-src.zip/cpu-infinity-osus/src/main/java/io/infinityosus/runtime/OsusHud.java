package io.infinityosus.runtime;

import io.infinityosus.OsusLog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/** Overlay renderer, called from GuiMixin at the tail of Gui.render. */
public final class OsusHud {
    private static List<String> cache;
    private static long lastRefresh;

    private OsusHud() {}

    public static void render(GuiGraphics g) {
        if (!OsusStats.overlay) {
            return;
        }
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui) {
                return;
            }
            long now = System.nanoTime();
            if (cache == null || now - lastRefresh > 250_000_000L) {
                cache = OsusStats.lines(true);
                lastRefresh = now;
            }
            Font font = mc.font;
            int width = 0;
            for (String s : cache) {
                width = Math.max(width, font.width(s));
            }
            g.fill(2, 2, width + 8, cache.size() * 10 + 6, 0x90000000);
            int y = 4;
            for (String s : cache) {
                g.drawString(font, s, 5, y, 0xFFFFFF, true);
                y += 10;
            }
        } catch (Throwable t) {
            OsusStats.overlay = false;
            OsusLog.warn("overlay disabled after error: " + t);
        }
    }
}
