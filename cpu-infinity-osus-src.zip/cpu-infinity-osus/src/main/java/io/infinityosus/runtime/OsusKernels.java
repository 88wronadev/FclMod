package io.infinityosus.runtime;

import io.infinityosus.natives.OsusNative;

import java.nio.ByteBuffer;

/**
 * Typed wrappers over the aux-buffer kernels. Main thread only. Input lives at aux offset 0,
 * output at OUT_BASE; the native side validates every range, so bad sizes just return -1.
 */
public final class OsusKernels {
    private static final int OUT_BASE = 4 << 20;
    public static final int SECTION_VOLUME = 4096;
    public static final int MAX_FACES_PER_SECTION = 12288;
    private static final int MESH_STRIDE = 4 + MAX_FACES_PER_SECTION * 4;

    private OsusKernels() {}

    /** Efficiency pool. Writes tick intervals (1, 2, 4, 8) per distance. Returns throttled count or -1. */
    public static int lod(float[] dist, int n, byte[] out) {
        ByteBuffer aux = OsusRuntime.aux();
        if (aux == null || n <= 0 || n > dist.length || n > out.length || n * 4 > OUT_BASE) {
            return -1;
        }
        aux.asFloatBuffer().put(0, dist, 0, n);
        long r = OsusNative.nativeSubmit(OsusNative.KIND_LOD, n, 0, 0, 0, 0, 0L, OUT_BASE);
        if (r < 0) {
            return -1;
        }
        aux.get(OUT_BASE, out, 0, n);
        return (int) r;
    }

    /**
     * Smart thread. Stable radix sort of 32-bit draw-state keys (e.g. shader id << 24 | texture id).
     * Fills outPerm with the sorted order; returns the number of distinct state groups, or -1.
     */
    public static int drawSort(int[] keys, int n, int[] outPerm) {
        ByteBuffer aux = OsusRuntime.aux();
        if (aux == null || n <= 0 || n > keys.length || n > outPerm.length || n * 4 > OUT_BASE) {
            return -1;
        }
        aux.asIntBuffer().put(0, keys, 0, n);
        long r = OsusNative.nativeSubmit(OsusNative.KIND_DRAW_SORT, n, 0, 0, 0, 0, 0L, OUT_BASE);
        if (r < 0) {
            return -1;
        }
        aux.asIntBuffer().get(OUT_BASE >> 2, outPerm, 0, n);
        return (int) r;
    }

    /** Performance pool. Far-to-near ordering of translucent quads by squared depth. */
    public static int vertexSort(float[] depth, int n, int[] outPerm) {
        ByteBuffer aux = OsusRuntime.aux();
        if (aux == null || n <= 0 || n > depth.length || n > outPerm.length || n * 4 > OUT_BASE) {
            return -1;
        }
        aux.asFloatBuffer().put(0, depth, 0, n);
        long r = OsusNative.nativeSubmit(OsusNative.KIND_VERT_SORT, n, 0, 0, 0, 0, 0L, OUT_BASE);
        if (r < 0) {
            return -1;
        }
        aux.asIntBuffer().get(OUT_BASE >> 2, outPerm, 0, n);
        return (int) r;
    }

    /**
     * Performance pool. Block-light flood fill over a w*h*d volume (each <= 128, index x + w*(y + h*z)).
     * opacity: 0 transparent. emission: 0..15. Returns relaxation passes used, or -1.
     */
    public static int propagateLight(byte[] opacity, byte[] emission, int w, int h, int d, byte[] out) {
        ByteBuffer aux = OsusRuntime.aux();
        long vol = (long) w * h * d;
        if (aux == null || w <= 0 || h <= 0 || d <= 0 || vol * 2 > OUT_BASE
                || opacity.length < vol || emission.length < vol || out.length < vol) {
            return -1;
        }
        int v = (int) vol;
        aux.put(0, opacity, 0, v);
        aux.put(v, emission, 0, v);
        long r = OsusNative.nativeSubmit(OsusNative.KIND_LIGHT, 0, w, h, d, 0, 0L, OUT_BASE);
        if (r < 0) {
            return -1;
        }
        aux.get(OUT_BASE, out, 0, v);
        return (int) r;
    }

    /**
     * Performance pool. Exposed-face extraction for up to 64 sections of 16^3 blocks
     * (solid[s*4096 + y*256 + z*16 + x] != 0 means opaque). faces[s*12288 + i] = x | y<<4 | z<<8 | dir<<12,
     * dir order +X,-X,+Y,-Y,+Z,-Z. Section borders count as exposed. Returns total faces, or -1.
     */
    public static int meshSections(byte[] solid, int sections, int[] faceCounts, int[] faces) {
        ByteBuffer aux = OsusRuntime.aux();
        if (aux == null || sections <= 0 || sections > 64 || solid.length < sections * SECTION_VOLUME
                || faceCounts.length < sections || faces.length < sections * MAX_FACES_PER_SECTION) {
            return -1;
        }
        aux.put(0, solid, 0, sections * SECTION_VOLUME);
        long r = OsusNative.nativeSubmit(OsusNative.KIND_MESH, sections, 0, 0, 0, 0, 0L, OUT_BASE);
        if (r < 0) {
            return -1;
        }
        for (int s = 0; s < sections; s++) {
            int base = OUT_BASE + s * MESH_STRIDE;
            int cnt = Math.min(aux.getInt(base), MAX_FACES_PER_SECTION);
            faceCounts[s] = cnt;
            aux.asIntBuffer().get((base + 4) >> 2, faces, s * MAX_FACES_PER_SECTION, cnt);
        }
        return (int) r;
    }

    /**
     * Efficiency pool. Occlusion in [0,1] for each sound source; sources within 16 blocks skip the math.
     * flags: dx*dy*dz bytes of 16-block sections (0 air, 1 partial, 2 solid), index (y*dz + z)*dx + x,
     * grid origin (ox,oy,oz) in world blocks. sources: xyz triplets. Returns occluded count, or -1.
     */
    public static int soundOcclusion(float lx, float ly, float lz, float ox, float oy, float oz,
                                     byte[] flags, int dx, int dy, int dz,
                                     float[] sources, int n, float[] out) {
        ByteBuffer aux = OsusRuntime.aux();
        int cells = dx * dy * dz;
        int fl = (cells + 3) & ~3;
        if (aux == null || n <= 0 || dx <= 0 || dy <= 0 || dz <= 0 || cells > 64 * 64 * 64
                || flags.length < cells || sources.length < n * 3 || out.length < n
                || (long) (24 + fl) + n * 12L > OUT_BASE) {
            return -1;
        }
        float[] hdr = {lx, ly, lz, ox, oy, oz};
        aux.asFloatBuffer().put(0, hdr, 0, 6);
        aux.put(24, flags, 0, cells);
        aux.asFloatBuffer().put((24 + fl) >> 2, sources, 0, n * 3);
        long r = OsusNative.nativeSubmit(OsusNative.KIND_SOUND, n, dx, dy, dz, 0, 0L, OUT_BASE);
        if (r < 0) {
            return -1;
        }
        aux.asFloatBuffer().get(OUT_BASE >> 2, out, 0, n);
        return (int) r;
    }
}
