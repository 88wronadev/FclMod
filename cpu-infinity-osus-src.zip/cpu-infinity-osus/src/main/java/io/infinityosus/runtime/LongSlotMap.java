package io.infinityosus.runtime;

/** Allocation-free open-addressing long -> int map with O(1) clear via epoch stamps. */
final class LongSlotMap {
    private final long[] keys;
    private final int[] vals;
    private final int[] stamps;
    private final int mask;
    private int epoch = 1;

    LongSlotMap(int capacityPow2) {
        if (Integer.bitCount(capacityPow2) != 1) {
            throw new IllegalArgumentException("capacity must be a power of two");
        }
        this.keys = new long[capacityPow2];
        this.vals = new int[capacityPow2];
        this.stamps = new int[capacityPow2];
        this.mask = capacityPow2 - 1;
    }

    void clear() {
        epoch++;
    }

    private int slot(long k) {
        return (int) ((k * 0x9E3779B97F4A7C15L) >>> 40) & mask;
    }

    /** Inserts only if absent. Returns true when inserted. */
    boolean put(long k, int v) {
        int i = slot(k);
        while (true) {
            if (stamps[i] != epoch) {
                stamps[i] = epoch;
                keys[i] = k;
                vals[i] = v;
                return true;
            }
            if (keys[i] == k) {
                return false;
            }
            i = (i + 1) & mask;
        }
    }

    int get(long k) {
        int i = slot(k);
        while (stamps[i] == epoch) {
            if (keys[i] == k) {
                return vals[i];
            }
            i = (i + 1) & mask;
        }
        return -1;
    }
}
