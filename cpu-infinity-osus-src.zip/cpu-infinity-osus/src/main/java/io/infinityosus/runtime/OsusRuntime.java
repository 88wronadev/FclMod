package io.infinityosus.runtime;

import io.infinityosus.OsusLog;
import io.infinityosus.natives.NativeLoader;
import io.infinityosus.natives.OsusNative;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BannerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.CampfireBlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Bridge between Minecraft and the Rust core. Everything here runs on the client main thread
 * (render + client tick share it); every public entry point fails open (returns "visible /
 * don't skip") and trips a circuit breaker on the first unexpected error.
 */
public final class OsusRuntime {
    // ---- layout, mirrored from lib.rs --------------------------------------------------------
    public static final int CAP = 8192;
    private static final int IN_HEADER = 256;
    private static final int RING_HDR = 128;
    private static final int RING_DATA = 1 << 16;
    private static final long RING_MASK = RING_DATA - 1L;
    private static final int REC_HDR = 24;
    private static final int MAGIC_DATA = 0x0C0FFEE1;
    private static final VarHandle LONG_VH =
            MethodHandles.byteBufferViewVarHandle(long[].class, ByteOrder.nativeOrder());

    // ---- tuning ------------------------------------------------------------------------------
    private static final float ENTITY_PAD = 1.0f;
    private static final float BE_PAD = 1.5f;
    private static final double FOV_SCALE = Double.parseDouble(System.getProperty("osus.fovScale", "1.35"));
    private static final double FOV_PAD_DEG = Double.parseDouble(System.getProperty("osus.fovPad", "6"));
    private static final long BE_BATCH_INTERVAL_NS = 45_000_000L;

    // ---- state -------------------------------------------------------------------------------
    private static volatile boolean bound;
    private static volatile boolean disabled;
    private static ByteBuffer in;
    private static ByteBuffer ring;
    private static ByteBuffer aux;
    private static Thread mainThread;
    private static int consecutiveFailures;

    private static long frame;
    private static long lastFrameNs;
    private static long lastEnd;

    private static double camX;
    private static double camY;
    private static double camZ;

    private static long batchFrame = -1;
    private static boolean batchValid;
    private static int batchWordsOff;
    private static final LongSlotMap entSlots = new LongSlotMap(CAP * 4);
    private static final float[] distBuf = new float[CAP];
    private static final long[] idBuf = new long[CAP];
    private static final byte[] lodOut = new byte[CAP];
    private static final LongSlotMap lodMap = new LongSlotMap(CAP * 4);

    private static LongSlotMap beStage = new LongSlotMap(CAP * 4);
    private static LongSlotMap beResult = new LongSlotMap(CAP * 4);
    private static final int[] beX = new int[CAP];
    private static final int[] beY = new int[CAP];
    private static final int[] beZ = new int[CAP];
    private static final int[] beWords = new int[CAP / 32];
    private static int beCount;
    private static long lastBeNs;

    private OsusRuntime() {}

    // ---- lifecycle ---------------------------------------------------------------------------

    private static boolean bind() {
        if (bound) {
            return true;
        }
        if (disabled || !NativeLoader.isLoaded()) {
            return false;
        }
        try {
            ByteBuffer i = OsusNative.nativeBuffer(0);
            ByteBuffer r = OsusNative.nativeBuffer(1);
            ByteBuffer a = OsusNative.nativeBuffer(2);
            if (i == null || r == null || a == null) {
                disabled = true;
                OsusLog.warn("native buffers unavailable, Osus disabled");
                return false;
            }
            in = i.order(ByteOrder.nativeOrder());
            ring = r.order(ByteOrder.nativeOrder());
            aux = a.order(ByteOrder.nativeOrder());
            lastEnd = (long) LONG_VH.getAcquire(ring, 64);
            bound = true;
            OsusLog.info("bound zero-copy buffers (NEON=" + OsusNative.nativeHasNeon() + ")");
            return true;
        } catch (Throwable t) {
            disable("bind", t);
            return false;
        }
    }

    static void disable(String where, Throwable t) {
        if (!disabled) {
            disabled = true;
            OsusLog.error("circuit breaker tripped in " + where + " - Osus now passive", t);
        }
    }

    private static void softFail(String where) {
        if (++consecutiveFailures >= 5) {
            disable(where, new IllegalStateException("5 consecutive native failures"));
        }
    }

    public static boolean isActive() {
        return bound && !disabled;
    }

    static ByteBuffer aux() {
        return isActive() ? aux : null;
    }

    // ---- frame boundary ----------------------------------------------------------------------

    /** Called at the head of Minecraft.runTick (once per rendered frame). */
    public static void beginFrame() {
        if (!bind() || disabled) {
            return;
        }
        try {
            long now = System.nanoTime();
            mainThread = Thread.currentThread();
            frame++;
            if (lastFrameNs != 0L) {
                OsusNative.nativeFrameMark(now - lastFrameNs);
            }
            lastFrameNs = now;
            runBlockEntityBatch(now);
        } catch (Throwable t) {
            disable("beginFrame", t);
        }
    }

    // ---- camera + frustum --------------------------------------------------------------------

    private static void setPlane(int i, double nx, double ny, double nz, double d) {
        int o = i * 16;
        in.putFloat(o, (float) nx);
        in.putFloat(o + 4, (float) ny);
        in.putFloat(o + 8, (float) nz);
        in.putFloat(o + 12, (float) d);
    }

    /**
     * Builds six camera-relative planes (inward normals, plane through the origin) from the camera
     * pose with a deliberately widened FOV, because the exact projection (sprint/underwater FOV
     * effects) is not read. Widening only ever keeps more things visible.
     */
    private static void updateCamera(Minecraft mc, Camera cam) {
        Vec3 p = cam.getPosition();
        camX = p.x;
        camY = p.y;
        camZ = p.z;
        double yaw = Math.toRadians(cam.getYRot());
        double pitch = Math.toRadians(cam.getXRot());
        double cp = Math.cos(pitch);
        double sp = Math.sin(pitch);
        double fx = -Math.sin(yaw) * cp;
        double fy = -sp;
        double fz = Math.cos(yaw) * cp;
        double rx = -Math.cos(yaw);
        double rz = -Math.sin(yaw);
        // up = right x forward (right.y == 0)
        double ux = -rz * fy;
        double uy = rz * fx - rx * fz;
        double uz = rx * fy;

        double fovDeg = mc.options.fov().get();
        double vfov = Math.min(170.0, fovDeg * FOV_SCALE + FOV_PAD_DEG);
        double tanV = Math.tan(Math.toRadians(vfov) * 0.5);
        int w = Math.max(1, mc.getWindow().getWidth());
        int h = Math.max(1, mc.getWindow().getHeight());
        double tanH = tanV * Math.max(0.5, (double) w / (double) h);

        setPlane(0, fx, fy, fz, 1.5); // near
        setPlane(1, fx * tanH - rx, fy * tanH, fz * tanH - rz, 0.0); // right edge
        setPlane(2, fx * tanH + rx, fy * tanH, fz * tanH + rz, 0.0); // left edge
        setPlane(3, fx * tanV + ux, fy * tanV + uy, fz * tanV + uz, 0.0); // bottom edge
        setPlane(4, fx * tanV - ux, fy * tanV - uy, fz * tanV - uz, 0.0); // top edge
        setPlane(5, -fx, -fy, -fz, 1024.0); // far
    }

    private static void putBox(int n, float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        int base = IN_HEADER + n * 4;
        int stride = CAP * 4;
        in.putFloat(base, minX);
        in.putFloat(base + stride, minY);
        in.putFloat(base + 2 * stride, minZ);
        in.putFloat(base + 3 * stride, maxX);
        in.putFloat(base + 4 * stride, maxY);
        in.putFloat(base + 5 * stride, maxZ);
    }

    /** Releases old records, submits a cull job, returns the ring record's physical offset or -1. */
    private static int submitCull(int n) {
        LONG_VH.setRelease(ring, 0, lastEnd);
        long abs = OsusNative.nativeSubmit(OsusNative.KIND_CULL, n, 0, 0, 0, 0, 0L, 0L);
        if (abs < 0) {
            softFail("cull");
            return -1;
        }
        int phys = RING_HDR + (int) (abs & RING_MASK);
        if (ring.getInt(phys) != MAGIC_DATA || ring.getInt(phys + 12) != n) {
            softFail("ring record");
            return -1;
        }
        consecutiveFailures = 0;
        lastEnd = abs + (ring.getInt(phys + 4) & 0xFFFFFFFFL);
        return phys;
    }

    // ---- entity batch ------------------------------------------------------------------------

    private static void runEntityBatch() {
        batchValid = false;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        Camera cam = mc.gameRenderer.getMainCamera();
        if (!cam.isInitialized()) {
            return;
        }
        updateCamera(mc, cam);
        final double cx = camX;
        final double cy = camY;
        final double cz = camZ;
        entSlots.clear();
        int n = 0;
        for (Entity e : level.entitiesForRendering()) {
            if (n >= CAP) {
                break;
            }
            AABB b = e.getBoundingBoxForCulling();
            putBox(n,
                    (float) (b.minX - ENTITY_PAD - cx), (float) (b.minY - ENTITY_PAD - cy), (float) (b.minZ - ENTITY_PAD - cz),
                    (float) (b.maxX + ENTITY_PAD - cx), (float) (b.maxY + ENTITY_PAD - cy), (float) (b.maxZ + ENTITY_PAD - cz));
            entSlots.put(e.getId(), n);
            idBuf[n] = e.getId();
            distBuf[n] = (float) Math.sqrt(e.distanceToSqr(cx, cy, cz));
            n++;
        }
        if (n == 0) {
            return;
        }
        long t0 = System.nanoTime();
        int phys = submitCull(n);
        OsusStats.lastCullNanos = System.nanoTime() - t0;
        if (phys < 0) {
            return;
        }
        batchWordsOff = phys + REC_HDR;
        OsusStats.lastBatchCount = n;
        OsusStats.lastBatchVisible = ring.getInt(phys + 16);
        batchValid = true;

        if ((frame & 3L) == 0L) {
            refreshLod(n);
        }
    }

    /** Efficiency pool: distance-bucket tick intervals, refreshed every 4th frame. */
    private static void refreshLod(int n) {
        if (OsusKernels.lod(distBuf, n, lodOut) >= 0) {
            lodMap.clear();
            for (int i = 0; i < n; i++) {
                lodMap.put(idBuf[i], lodOut[i]);
            }
        }
    }

    private static void ensureBatch() {
        if (batchFrame != frame) {
            batchFrame = frame;
            runEntityBatch();
        }
    }

    private static boolean slotVisible(int slot) {
        return ((ring.getInt(batchWordsOff + ((slot >> 5) << 2)) >>> (slot & 31)) & 1) != 0;
    }

    private static boolean exempt(Entity e) {
        Entity ce = Minecraft.getInstance().getCameraEntity();
        if (ce != null && (e == ce || e.getRootVehicle() == ce.getRootVehicle())) {
            return true;
        }
        double dx = e.getX() - camX;
        double dy = e.getY() - camY;
        double dz = e.getZ() - camZ;
        return dx * dx + dy * dy + dz * dz < 16.0;
    }

    /** True when the NEON precision pass says this entity is outside the (widened) view frustum. */
    public static boolean isEntityCulled(Entity e) {
        if (!bound || disabled || Thread.currentThread() != mainThread) {
            return false;
        }
        try {
            ensureBatch();
            if (!batchValid) {
                return false;
            }
            int slot = entSlots.get(e.getId());
            if (slot < 0 || slotVisible(slot) || exempt(e)) {
                return false;
            }
            OsusStats.entitiesCulled.increment();
            return true;
        } catch (Throwable t) {
            disable("isEntityCulled", t);
            return false;
        }
    }

    /**
     * Client-side only visual throttle: culled entities beyond 24 blocks and distant ones (LOD)
     * tick at 5 Hz / 10 Hz instead of 20 Hz. Players, riders, vehicles and projectiles are never touched.
     */
    public static boolean shouldSkipEntityTick(Entity e) {
        if (!bound || disabled || !batchValid || Thread.currentThread() != mainThread) {
            return false;
        }
        try {
            if (!(e instanceof LivingEntity) && !(e instanceof ItemEntity)) {
                return false;
            }
            if (e instanceof Player || e.isPassenger() || e.isVehicle()) {
                return false;
            }
            long id = e.getId();
            int interval = 1;
            int slot = entSlots.get(id);
            if (slot >= 0 && !slotVisible(slot)) {
                double dx = e.getX() - camX;
                double dy = e.getY() - camY;
                double dz = e.getZ() - camZ;
                if (dx * dx + dy * dy + dz * dz > 576.0) {
                    interval = 4;
                }
            }
            int lod = lodMap.get(id);
            if (lod > interval) {
                interval = lod;
            }
            if (interval > 4) {
                interval = 4;
            }
            if (interval <= 1) {
                return false;
            }
            if (((e.level().getGameTime() + id) % interval) == 0) {
                return false;
            }
            OsusStats.entityTicksThrottled.increment();
            return true;
        } catch (Throwable t) {
            disable("shouldSkipEntityTick", t);
            return false;
        }
    }

    // ---- block entities ----------------------------------------------------------------------

    private static boolean throttleable(BlockEntity be) {
        return be instanceof ChestBlockEntity
                || be instanceof EnderChestBlockEntity
                || be instanceof SignBlockEntity
                || be instanceof BannerBlockEntity
                || be instanceof CampfireBlockEntity;
    }

    private static void runBlockEntityBatch(long now) {
        if (beCount == 0 || now - lastBeNs < BE_BATCH_INTERVAL_NS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            beCount = 0;
            beStage.clear();
            return;
        }
        Camera cam = mc.gameRenderer.getMainCamera();
        if (!cam.isInitialized()) {
            return;
        }
        updateCamera(mc, cam);
        final double cx = camX;
        final double cy = camY;
        final double cz = camZ;
        int n = beCount;
        for (int i = 0; i < n; i++) {
            putBox(i,
                    (float) (beX[i] - BE_PAD - cx), (float) (beY[i] - BE_PAD - cy), (float) (beZ[i] - BE_PAD - cz),
                    (float) (beX[i] + 1 + BE_PAD - cx), (float) (beY[i] + 1 + BE_PAD - cy), (float) (beZ[i] + 1 + BE_PAD - cz));
        }
        int phys = submitCull(n);
        lastBeNs = now;
        if (phys < 0) {
            return;
        }
        int words = (n + 31) >> 5;
        for (int w = 0; w < words; w++) {
            beWords[w] = ring.getInt(phys + REC_HDR + (w << 2));
        }
        LongSlotMap old = beResult;
        beResult = beStage;
        beStage = old;
        beStage.clear();
        beCount = 0;
        OsusStats.beBatches.increment();
    }

    /** Client-side chests, signs, banners and campfires that are outside the frustum tick at 5 Hz. */
    public static boolean shouldSkipBlockEntityTick(BlockEntity be) {
        Level level = be.getLevel();
        if (level == null || !level.isClientSide()) {
            return false;
        }
        if (!bound || disabled || Thread.currentThread() != mainThread || !throttleable(be)) {
            return false;
        }
        try {
            BlockPos pos = be.getBlockPos();
            long key = pos.asLong();
            if (beCount < CAP && beStage.put(key, beCount)) {
                beX[beCount] = pos.getX();
                beY[beCount] = pos.getY();
                beZ[beCount] = pos.getZ();
                beCount++;
            }
            int slot = beResult.get(key);
            if (slot < 0 || ((beWords[slot >> 5] >>> (slot & 31)) & 1) != 0) {
                return false;
            }
            if (((level.getGameTime() + (key ^ (key >>> 17))) & 3L) == 0L) {
                return false;
            }
            OsusStats.blockEntityTicksThrottled.increment();
            return true;
        } catch (Throwable t) {
            disable("shouldSkipBlockEntityTick", t);
            return false;
        }
    }

    // ---- AABB collision batch (Precision pool, NEON) -----------------------------------------

    /**
     * Tests {@code q} = {minX,minY,minZ,maxX,maxY,maxZ} against n boxes laid out as 6 floats each
     * (min xyz, max xyz). Fills {@code hit}; returns the hit count or -1.
     */
    public static int aabbOverlap(float[] q, float[] boxes, int n, boolean[] hit) {
        if (!isActive() || n <= 0 || n > CAP || q.length < 6 || boxes.length < n * 6 || hit.length < n
                || Thread.currentThread() != mainThread) {
            return -1;
        }
        try {
            for (int i = 0; i < 6; i++) {
                in.putFloat(112 + i * 4, q[i]);
            }
            for (int i = 0; i < n; i++) {
                putBox(i, boxes[i * 6], boxes[i * 6 + 1], boxes[i * 6 + 2],
                        boxes[i * 6 + 3], boxes[i * 6 + 4], boxes[i * 6 + 5]);
            }
            LONG_VH.setRelease(ring, 0, lastEnd);
            long abs = OsusNative.nativeSubmit(OsusNative.KIND_OVERLAP, n, 0, 0, 0, 0, 0L, 0L);
            if (abs < 0) {
                return -1;
            }
            int phys = RING_HDR + (int) (abs & RING_MASK);
            if (ring.getInt(phys) != MAGIC_DATA) {
                return -1;
            }
            lastEnd = abs + (ring.getInt(phys + 4) & 0xFFFFFFFFL);
            int hits = 0;
            for (int i = 0; i < n; i++) {
                boolean h = ((ring.getInt(phys + REC_HDR + ((i >> 5) << 2)) >>> (i & 31)) & 1) != 0;
                hit[i] = h;
                if (h) {
                    hits++;
                }
            }
            return hits;
        } catch (Throwable t) {
            disable("aabbOverlap", t);
            return -1;
        }
    }
}
