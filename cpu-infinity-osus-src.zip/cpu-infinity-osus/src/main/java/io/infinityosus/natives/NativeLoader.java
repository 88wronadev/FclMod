package io.infinityosus.natives;

import io.infinityosus.OsusLog;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Extracts natives/android-arm64/libinfinity_osus.so from the jar into gameDir/osus_natives and
 * System.load()s it. If the game directory is mounted noexec (common on Android shared storage)
 * it falls back to java.io.tmpdir and user.home. Every failure path returns false; nothing throws.
 */
public final class NativeLoader {
    private static final String RESOURCE = "/natives/android-arm64/libinfinity_osus.so";
    private static final String FILE_NAME = "libinfinity_osus.so";

    private static volatile boolean loaded;
    private static volatile String failure = "not attempted";
    private static volatile String loadedFrom = "";

    private NativeLoader() {}

    public static boolean isLoaded() {
        return loaded;
    }

    public static String failure() {
        return failure;
    }

    public static String loadedFrom() {
        return loadedFrom;
    }

    public static synchronized boolean load(Path gameDir) {
        if (loaded) {
            return true;
        }
        try {
            String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
            if (!arch.equals("aarch64") && !arch.equals("arm64")) {
                failure = "not an aarch64 JVM (os.arch=" + arch + ")";
                return false;
            }
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            if (!os.contains("linux") && !os.contains("android")) {
                failure = "unsupported os.name=" + os;
                return false;
            }

            byte[] data;
            try (InputStream in = NativeLoader.class.getResourceAsStream(RESOURCE)) {
                if (in == null) {
                    failure = "jar does not contain " + RESOURCE;
                    return false;
                }
                data = in.readAllBytes();
            }

            List<Path> dirs = new ArrayList<>();
            if (gameDir != null) {
                dirs.add(gameDir.resolve("osus_natives"));
            }
            String tmp = System.getProperty("java.io.tmpdir");
            if (tmp != null && !tmp.isEmpty()) {
                dirs.add(Paths.get(tmp, "osus_natives"));
            }
            String home = System.getProperty("user.home");
            if (home != null && !home.isEmpty()) {
                dirs.add(Paths.get(home, ".osus_natives"));
            }

            StringBuilder errors = new StringBuilder();
            for (Path dir : dirs) {
                try {
                    Files.createDirectories(dir);
                    Path target = dir.resolve(FILE_NAME);
                    if (!Files.exists(target) || !Arrays.equals(Files.readAllBytes(target), data)) {
                        Path tmpFile = dir.resolve(FILE_NAME + ".tmp");
                        Files.write(tmpFile, data);
                        Files.move(tmpFile, target, StandardCopyOption.REPLACE_EXISTING);
                    }
                    target.toFile().setReadable(true, false);
                    target.toFile().setExecutable(true, false);
                    System.load(target.toAbsolutePath().toString());
                    if (!OsusNative.nativeInit()) {
                        failure = "nativeInit() returned false";
                        return false;
                    }
                    loaded = true;
                    loadedFrom = target.toAbsolutePath().toString();
                    failure = "";
                    return true;
                } catch (Throwable t) {
                    errors.append(dir).append(": ").append(t).append("; ");
                }
            }
            failure = errors.length() == 0 ? "no usable directory" : errors.toString();
            return false;
        } catch (Throwable t) {
            failure = String.valueOf(t);
            OsusLog.warn("native load error: " + t);
            return false;
        }
    }
}
