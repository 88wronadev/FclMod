package io.infinityosus.natives;

import java.nio.ByteBuffer;

/** JNI surface of libinfinity_osus.so. Only call after {@link NativeLoader#load} returned true. */
public final class OsusNative {
    public static final int KIND_CULL = 1;
    public static final int KIND_OVERLAP = 2;
    public static final int KIND_LOD = 3;
    public static final int KIND_SOUND = 4;
    public static final int KIND_DRAW_SORT = 5;
    public static final int KIND_VERT_SORT = 6;
    public static final int KIND_LIGHT = 7;
    public static final int KIND_MESH = 8;

    private OsusNative() {}

    public static native boolean nativeInit();

    public static native boolean nativeHasNeon();

    /** 0 = input, 1 = ring, 2 = aux. Direct buffer over native memory (set byte order to native). */
    public static native ByteBuffer nativeBuffer(int which);

    /** Blocks (max 60 ms) for the result; -1 on failure. */
    public static native long nativeSubmit(int kind, int count, int p0, int p1, int p2, int p3, long inOff, long outOff);

    public static native void nativeFrameMark(long frameNs);

    public static native void nativeGetStats(long[] out);

    public static native void nativeShutdown();
}
