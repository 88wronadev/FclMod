package io.infinityosus;

import io.infinityosus.natives.NativeLoader;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

/** Runs before Minecraft classes load: extracts and loads libinfinity_osus.so on aarch64. Never throws. */
public final class OsusPreLaunch implements PreLaunchEntrypoint {
    @Override
    public void onPreLaunch() {
        try {
            if (Boolean.getBoolean("osus.disable")) {
                OsusLog.info("disabled via -Dosus.disable=true");
                return;
            }
            boolean ok = NativeLoader.load(FabricLoader.getInstance().getGameDir());
            if (ok) {
                OsusLog.info("native core loaded from " + NativeLoader.loadedFrom());
            } else {
                OsusLog.warn("native core unavailable, Osus stays inactive: " + NativeLoader.failure());
            }
        } catch (Throwable t) {
            OsusLog.warn("pre-launch failed safely: " + t);
        }
    }
}
