//! CPU Infinity Osus - native core (libinfinity_osus.so, aarch64-linux-android).
//!
//! Thread domains (14 base threads, bursting to 16):
//!   0 Performance : rayon pool, 6 threads allocated, 4 active, governor bursts to 6
//!   1 Fast        : rayon pool, 2 threads, publishes results into the zero-copy ring buffer
//!   2 Precision   : rayon pool, 2 threads, ARM NEON frustum / AABB kernels
//!   3 Smart       : 1 control thread, 12.5 ms frame governor + draw-call sorter
//!   4 Efficiency  : rayon pool, 4 threads (1..4 active), LOD ticks + sound occlusion, low priority
//!   5 Osus        : 1 router thread, lock-free MPMC entry point for every Java request
//!
//! Java talks to three direct ByteBuffers allocated here (see `nativeBuffer`):
//!   0 input : camera planes + SoA AABBs written by Java
//!   1 ring  : SPSC byte ring (Rust producer, Java consumer) carrying visibility bitmasks
//!   2 aux   : scratch region for the non-hot kernels (LOD, sort, light, mesh, sound)

use std::alloc::{alloc_zeroed, Layout};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::slice;
use std::sync::atomic::{AtomicBool, AtomicI64, AtomicU32, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::thread::{self, Thread};
use std::time::{Duration, Instant};

use crossbeam::queue::ArrayQueue;
use jni::objects::{JClass, JLongArray};
use jni::sys::{jboolean, jint, jlong, jobject, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use rayon::prelude::*;
use rayon::{ThreadPool, ThreadPoolBuilder};

// ---------------------------------------------------------------------------
// Layout constants (mirrored in OsusRuntime.java)
// ---------------------------------------------------------------------------

const CAP: usize = 8192; // max AABBs per batch
const IN_HEADER: usize = 256; // bytes: 6 planes (96) | query box @112 (24) | reserved
const IN_LEN: usize = IN_HEADER + 6 * CAP * 4;
const RING_HDR: usize = 128; // head u64 @0 (Java), tail u64 @64 (Rust)
const RING_DATA: usize = 1 << 16;
const RING_LEN: usize = RING_HDR + RING_DATA;
const AUX_LEN: usize = 8 << 20;

const REC_MAGIC: u32 = 0x0C0F_FEE1;
const PAD_MAGIC: u32 = 0x0BAD_BEEF;
const REC_HDR: usize = 24;

const FRAME_TARGET_US: f64 = 12_500.0; // 80 FPS
const PERF_BASE: usize = 4;
const PERF_MAX: usize = 6;
const FAST_N: usize = 2;
const PREC_N: usize = 2;
const EFF_N: usize = 4;

const PERF: usize = 0;
const FAST: usize = 1;
const PREC: usize = 2;
const SMART: usize = 3;
const EFF: usize = 4;
const OSUS: usize = 5;

const SEC: usize = 4096; // 16^3 section
const MAXF: usize = 12288; // worst-case exposed faces in a 16^3 section
const MSTRIDE: usize = 4 + MAXF * 4;

// ---------------------------------------------------------------------------
// Plumbing types
// ---------------------------------------------------------------------------

struct RawBuf {
    ptr: *mut u8,
    len: usize,
}
unsafe impl Send for RawBuf {}
unsafe impl Sync for RawBuf {}

impl RawBuf {
    fn new(len: usize) -> RawBuf {
        let layout = Layout::from_size_align(len, 64).expect("osus: bad layout");
        let ptr = unsafe { alloc_zeroed(layout) };
        assert!(!ptr.is_null(), "osus: native allocation failed");
        RawBuf { ptr, len }
    }
}

struct Domain {
    base: usize,
    max: usize,
    active: AtomicUsize,
    busy_ns: AtomicU64,
    tasks: AtomicU64,
}

impl Domain {
    fn new(base: usize, max: usize) -> Domain {
        Domain {
            base,
            max,
            active: AtomicUsize::new(base),
            busy_ns: AtomicU64::new(0),
            tasks: AtomicU64::new(0),
        }
    }
}

struct Busy<'a> {
    dom: &'a Domain,
    start: Instant,
}

impl<'a> Busy<'a> {
    fn new(dom: &'a Domain) -> Busy<'a> {
        Busy { dom, start: Instant::now() }
    }
}

impl Drop for Busy<'_> {
    fn drop(&mut self) {
        self.dom
            .busy_ns
            .fetch_add(self.start.elapsed().as_nanos() as u64, Ordering::Relaxed);
        self.dom.tasks.fetch_add(1, Ordering::Relaxed);
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Kind {
    Cull,
    Overlap,
    Lod,
    SoundOcc,
    DrawSort,
    VertSort,
    Light,
    Mesh,
}

impl Kind {
    fn from_i32(v: i32) -> Option<Kind> {
        Some(match v {
            1 => Kind::Cull,
            2 => Kind::Overlap,
            3 => Kind::Lod,
            4 => Kind::SoundOcc,
            5 => Kind::DrawSort,
            6 => Kind::VertSort,
            7 => Kind::Light,
            8 => Kind::Mesh,
            _ => return None,
        })
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Mode {
    Frustum,
    Overlap,
}

struct Done {
    state: AtomicU32, // 0 pending, 1 ok, 2 failed
    result: AtomicI64,
    waiter: Thread,
}

impl Done {
    fn finish(&self, ok: bool, result: i64) {
        self.result.store(result, Ordering::Release);
        self.state.store(if ok { 1 } else { 2 }, Ordering::Release);
        self.waiter.unpark();
    }
}

#[derive(Clone)]
struct Job {
    kind: Kind,
    count: usize,
    p: [u32; 4],
    in_off: usize,
    out_off: usize,
    done: Arc<Done>,
}

enum Outcome {
    Done(i64),
    Failed,
    Forwarded,
}

struct SnapState {
    ts: Instant,
    busy: [u64; 6],
    util: [u64; 6],
}

struct Runtime {
    doms: [Domain; 6],
    perf: ThreadPool,
    fast: ThreadPool,
    prec: ThreadPool,
    eff: ThreadPool,
    input: RawBuf,
    ring: RawBuf,
    aux: RawBuf,
    scratch: Mutex<Vec<u32>>,
    router_q: ArrayQueue<Job>,
    smart_q: ArrayQueue<Job>,
    router_thread: OnceLock<Thread>,
    smart_thread: OnceLock<Thread>,
    ring_seq: AtomicU32,
    frame_ns: AtomicU64,
    ema_us: AtomicU64, // f64 bits
    last_mark_ms: AtomicU64,
    epoch: Instant,
    shutdown: AtomicBool,
    neon_tested: AtomicU64,
    neon_culled: AtomicU64,
    burst_events: AtomicU64,
    gov_steps: AtomicU64,
    dropped: AtomicU64,
    last_cull_us: AtomicU64,
    snap: Mutex<SnapState>,
}

static RT: OnceLock<Runtime> = OnceLock::new();

// ---------------------------------------------------------------------------
// Android thread tuning
// ---------------------------------------------------------------------------

fn read_u64(path: &str) -> Option<u64> {
    std::fs::read_to_string(path).ok()?.trim().parse().ok()
}

/// Returns (little_mask, big_mask); (0, 0) when the SoC is symmetric or unreadable.
fn cpu_masks() -> (u64, u64) {
    let n = thread::available_parallelism().map(|v| v.get()).unwrap_or(8).min(64);
    let mut caps = Vec::with_capacity(n);
    for i in 0..n {
        let base = format!("/sys/devices/system/cpu/cpu{i}");
        let cap = read_u64(&format!("{base}/cpu_capacity"))
            .or_else(|| read_u64(&format!("{base}/cpufreq/cpuinfo_max_freq")))
            .unwrap_or(0);
        caps.push(cap);
    }
    let max = caps.iter().copied().max().unwrap_or(0);
    let min = caps.iter().copied().min().unwrap_or(0);
    if max == 0 || max == min {
        return (0, 0);
    }
    let thresh = (max + min) / 2;
    let (mut little, mut big) = (0u64, 0u64);
    for (i, c) in caps.iter().enumerate() {
        if *c > thresh {
            big |= 1u64 << i;
        } else {
            little |= 1u64 << i;
        }
    }
    (little, big)
}

fn pin_current(mask: u64) {
    #[cfg(any(target_os = "linux", target_os = "android"))]
    unsafe {
        if mask == 0 {
            return;
        }
        let mut set: libc::cpu_set_t = std::mem::zeroed();
        for cpu in 0..64usize {
            if (mask >> cpu) & 1 == 1 {
                libc::CPU_SET(cpu, &mut set);
            }
        }
        libc::sched_setaffinity(0, std::mem::size_of::<libc::cpu_set_t>(), &set);
    }
    #[cfg(not(any(target_os = "linux", target_os = "android")))]
    {
        let _ = mask;
    }
}

fn set_nice(nice: i32) {
    #[cfg(any(target_os = "linux", target_os = "android"))]
    unsafe {
        if nice == 0 {
            return;
        }
        let tid = libc::syscall(libc::SYS_gettid) as libc::id_t;
        libc::setpriority(libc::PRIO_PROCESS as _, tid, nice);
    }
    #[cfg(not(any(target_os = "linux", target_os = "android")))]
    {
        let _ = nice;
    }
}

fn build_pool(tag: &'static str, n: usize, mask: u64, nice: i32) -> ThreadPool {
    ThreadPoolBuilder::new()
        .num_threads(n)
        .thread_name(move |i| format!("osus-{tag}-{i}"))
        .start_handler(move |_| {
            pin_current(mask);
            set_nice(nice);
        })
        .panic_handler(|_| {})
        .build()
        .expect("osus: thread pool")
}

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------

fn init_runtime() -> bool {
    if RT.get().is_some() {
        return true;
    }
    let (little, big) = cpu_masks();
    let rt = Runtime {
        doms: [
            Domain::new(PERF_BASE, PERF_MAX),
            Domain::new(FAST_N, FAST_N),
            Domain::new(PREC_N, PREC_N),
            Domain::new(1, 1),
            Domain::new(EFF_N, EFF_N),
            Domain::new(1, 1),
        ],
        perf: build_pool("perf", PERF_MAX, 0, 0),
        fast: build_pool("fast", FAST_N, big, 0),
        prec: build_pool("prec", PREC_N, big, 0),
        eff: build_pool("eff", EFF_N, little, 10),
        input: RawBuf::new(IN_LEN),
        ring: RawBuf::new(RING_LEN),
        aux: RawBuf::new(AUX_LEN),
        scratch: Mutex::new(vec![0u32; CAP]),
        router_q: ArrayQueue::new(256),
        smart_q: ArrayQueue::new(256),
        router_thread: OnceLock::new(),
        smart_thread: OnceLock::new(),
        ring_seq: AtomicU32::new(0),
        frame_ns: AtomicU64::new(0),
        ema_us: AtomicU64::new(0f64.to_bits()),
        last_mark_ms: AtomicU64::new(0),
        epoch: Instant::now(),
        shutdown: AtomicBool::new(false),
        neon_tested: AtomicU64::new(0),
        neon_culled: AtomicU64::new(0),
        burst_events: AtomicU64::new(0),
        gov_steps: AtomicU64::new(0),
        dropped: AtomicU64::new(0),
        last_cull_us: AtomicU64::new(0),
        snap: Mutex::new(SnapState {
            ts: Instant::now(),
            busy: [0; 6],
            util: [0; 6],
        }),
    };
    if RT.set(rt).is_err() {
        return RT.get().is_some();
    }
    let rt: &'static Runtime = match RT.get() {
        Some(r) => r,
        None => return false,
    };

    let router = thread::Builder::new()
        .name("osus-router".into())
        .spawn(move || router_main(rt, big));
    let smart = thread::Builder::new()
        .name("osus-smart".into())
        .spawn(move || smart_main(rt, big));
    match (router, smart) {
        (Ok(r), Ok(s)) => {
            let _ = rt.router_thread.set(r.thread().clone());
            let _ = rt.smart_thread.set(s.thread().clone());
            true
        }
        _ => {
            rt.shutdown.store(true, Ordering::Relaxed);
            false
        }
    }
}

// ---------------------------------------------------------------------------
// Osus router thread (lock-free entry) and job submission
// ---------------------------------------------------------------------------

fn submit(kind: Kind, count: usize, p: [u32; 4], in_off: usize, out_off: usize) -> i64 {
    let rt = match RT.get() {
        Some(r) => r,
        None => return -1,
    };
    let router = match rt.router_thread.get() {
        Some(t) => t,
        None => return -1,
    };
    let done = Arc::new(Done {
        state: AtomicU32::new(0),
        result: AtomicI64::new(-1),
        waiter: thread::current(),
    });
    let job = Job { kind, count, p, in_off, out_off, done: done.clone() };
    if rt.router_q.push(job).is_err() {
        rt.dropped.fetch_add(1, Ordering::Relaxed);
        return -1;
    }
    router.unpark();
    let deadline = Instant::now() + Duration::from_millis(60);
    let mut spins = 0u32;
    loop {
        if done.state.load(Ordering::Acquire) != 0 {
            break;
        }
        if spins < 2000 {
            spins += 1;
            std::hint::spin_loop();
        } else {
            if Instant::now() >= deadline {
                return -1;
            }
            thread::park_timeout(Duration::from_micros(300));
        }
    }
    if done.state.load(Ordering::Acquire) == 1 {
        done.result.load(Ordering::Acquire)
    } else {
        -1
    }
}

fn router_main(rt: &'static Runtime, big: u64) {
    pin_current(big);
    while !rt.shutdown.load(Ordering::Relaxed) {
        match rt.router_q.pop() {
            Some(job) => {
                let _b = Busy::new(&rt.doms[OSUS]);
                dispatch(rt, job);
            }
            None => thread::park_timeout(Duration::from_millis(50)),
        }
    }
}

fn dispatch(rt: &'static Runtime, job: Job) {
    let done = job.done.clone();
    let r = catch_unwind(AssertUnwindSafe(|| run_job(rt, &job)));
    match r {
        Ok(Outcome::Done(v)) => done.finish(true, v),
        Ok(Outcome::Forwarded) => {}
        _ => done.finish(false, -1),
    }
}

fn run_job(rt: &'static Runtime, job: &Job) -> Outcome {
    let res = match job.kind {
        Kind::Cull => do_boxes(rt, job.count, Mode::Frustum),
        Kind::Overlap => do_boxes(rt, job.count, Mode::Overlap),
        Kind::Lod => k_lod(rt, job),
        Kind::SoundOcc => k_sound(rt, job),
        Kind::VertSort => k_vert_sort(rt, job),
        Kind::Light => k_light(rt, job),
        Kind::Mesh => k_mesh(rt, job),
        Kind::DrawSort => {
            // Draw-call sorting belongs to the Smart thread.
            if rt.smart_q.push(job.clone()).is_err() {
                return Outcome::Failed;
            }
            if let Some(t) = rt.smart_thread.get() {
                t.unpark();
            }
            return Outcome::Forwarded;
        }
    };
    match res {
        Some(v) => Outcome::Done(v),
        None => Outcome::Failed,
    }
}

// ---------------------------------------------------------------------------
// Precision domain: NEON frustum culling + AABB overlap
// ---------------------------------------------------------------------------

unsafe fn kernel_scalar(
    base: *const f32,
    mode: Mode,
    planes: &[[f32; 4]; 6],
    q: &[f32; 6],
    start: usize,
    out: &mut [u32],
    from: usize,
) {
    let data = base.add(IN_HEADER / 4);
    let at = |axis: usize, idx: usize| -> f32 { *data.add(axis * CAP + idx) };
    for i in from..out.len() {
        let g = start + i;
        let (mnx, mny, mnz) = (at(0, g), at(1, g), at(2, g));
        let (mxx, mxy, mxz) = (at(3, g), at(4, g), at(5, g));
        let vis = match mode {
            Mode::Frustum => {
                let mut ok = true;
                for p in planes.iter() {
                    let x = if p[0] >= 0.0 { mxx } else { mnx };
                    let y = if p[1] >= 0.0 { mxy } else { mny };
                    let z = if p[2] >= 0.0 { mxz } else { mnz };
                    if p[0] * x + p[1] * y + p[2] * z + p[3] < 0.0 {
                        ok = false;
                        break;
                    }
                }
                ok
            }
            Mode::Overlap => {
                q[0] <= mxx && q[3] >= mnx && q[1] <= mxy && q[4] >= mny && q[2] <= mxz && q[5] >= mnz
            }
        };
        out[i] = if vis { u32::MAX } else { 0 };
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn kernel(
    base: *const f32,
    mode: Mode,
    planes: &[[f32; 4]; 6],
    q: &[f32; 6],
    start: usize,
    out: &mut [u32],
) {
    use std::arch::aarch64::*;
    let data = base.add(IN_HEADER / 4);
    let minx = data;
    let miny = data.add(CAP);
    let minz = data.add(2 * CAP);
    let maxx = data.add(3 * CAP);
    let maxy = data.add(4 * CAP);
    let maxz = data.add(5 * CAP);
    let n = out.len();
    let mut i = 0usize;
    while i + 4 <= n {
        let g = start + i;
        let vis = match mode {
            Mode::Frustum => {
                let mut outside = vdupq_n_u32(0);
                let zero = vdupq_n_f32(0.0);
                for p in planes.iter() {
                    let px = if p[0] >= 0.0 { maxx } else { minx };
                    let py = if p[1] >= 0.0 { maxy } else { miny };
                    let pz = if p[2] >= 0.0 { maxz } else { minz };
                    let mut d = vdupq_n_f32(p[3]);
                    d = vfmaq_f32(d, vld1q_f32(px.add(g)), vdupq_n_f32(p[0]));
                    d = vfmaq_f32(d, vld1q_f32(py.add(g)), vdupq_n_f32(p[1]));
                    d = vfmaq_f32(d, vld1q_f32(pz.add(g)), vdupq_n_f32(p[2]));
                    outside = vorrq_u32(outside, vcltq_f32(d, zero));
                }
                vmvnq_u32(outside)
            }
            Mode::Overlap => {
                let mut m = vdupq_n_u32(u32::MAX);
                m = vandq_u32(m, vcleq_f32(vdupq_n_f32(q[0]), vld1q_f32(maxx.add(g))));
                m = vandq_u32(m, vcgeq_f32(vdupq_n_f32(q[3]), vld1q_f32(minx.add(g))));
                m = vandq_u32(m, vcleq_f32(vdupq_n_f32(q[1]), vld1q_f32(maxy.add(g))));
                m = vandq_u32(m, vcgeq_f32(vdupq_n_f32(q[4]), vld1q_f32(miny.add(g))));
                m = vandq_u32(m, vcleq_f32(vdupq_n_f32(q[2]), vld1q_f32(maxz.add(g))));
                m = vandq_u32(m, vcgeq_f32(vdupq_n_f32(q[5]), vld1q_f32(minz.add(g))));
                m
            }
        };
        vst1q_u32(out.as_mut_ptr().add(i), vis);
        i += 4;
    }
    if i < n {
        kernel_scalar(base, mode, planes, q, start, out, i);
    }
}

#[cfg(not(target_arch = "aarch64"))]
unsafe fn kernel(
    base: *const f32,
    mode: Mode,
    planes: &[[f32; 4]; 6],
    q: &[f32; 6],
    start: usize,
    out: &mut [u32],
) {
    kernel_scalar(base, mode, planes, q, start, out, 0);
}

/// Reserve `total` bytes in the ring. Returns (absolute start, physical offset inside data region).
fn ring_reserve(rt: &Runtime, total: usize) -> Option<(u64, usize)> {
    let hdr = rt.ring.ptr;
    let head = unsafe { &*(hdr as *const AtomicU64) }.load(Ordering::Acquire);
    let mut tail = unsafe { &*(hdr.add(64) as *const AtomicU64) }.load(Ordering::Relaxed);
    let mask = (RING_DATA as u64) - 1;
    let phys = (tail & mask) as usize;
    let remaining = RING_DATA - phys;
    let mut need = total;
    if remaining < total {
        need += remaining;
    }
    if (tail.wrapping_sub(head)) as usize + need > RING_DATA {
        return None;
    }
    if remaining < total {
        unsafe {
            let p = hdr.add(RING_HDR + phys) as *mut u32;
            *p = PAD_MAGIC;
            *p.add(1) = remaining as u32;
        }
        tail += remaining as u64;
        return Some((tail, 0));
    }
    Some((tail, phys))
}

/// Fast domain: pack the u32 lane masks into bit words and publish a record into the ring.
fn publish_mask(rt: &'static Runtime, count: usize, vis: &[u32]) -> Option<i64> {
    let words = (count + 31) / 32;
    let total = (REC_HDR + words * 4 + 7) & !7;
    let (abs, phys) = ring_reserve(rt, total)?;
    let rec = unsafe { rt.ring.ptr.add(RING_HDR + phys) };
    let wslice = unsafe { slice::from_raw_parts_mut(rec.add(REC_HDR) as *mut u32, words) };
    let visible = AtomicU32::new(0);
    let per = ((words + FAST_N - 1) / FAST_N).max(1);
    rt.fast.install(|| {
        wslice.par_chunks_mut(per).enumerate().for_each(|(ci, chunk)| {
            let _b = Busy::new(&rt.doms[FAST]);
            let mut cnt = 0u32;
            for (wi, w) in chunk.iter_mut().enumerate() {
                let first = (ci * per + wi) * 32;
                let lim = (count - first).min(32);
                let mut bits = 0u32;
                for b in 0..lim {
                    bits |= ((vis[first + b] != 0) as u32) << b;
                }
                *w = bits;
                cnt += bits.count_ones();
            }
            visible.fetch_add(cnt, Ordering::Relaxed);
        });
    });
    let seq = rt.ring_seq.fetch_add(1, Ordering::Relaxed);
    unsafe {
        let h = rec as *mut u32;
        *h = REC_MAGIC;
        *h.add(1) = total as u32;
        *h.add(2) = seq;
        *h.add(3) = count as u32;
        *h.add(4) = visible.load(Ordering::Relaxed);
        *h.add(5) = words as u32;
        (&*(rt.ring.ptr.add(64) as *const AtomicU64)).store(abs + total as u64, Ordering::Release);
    }
    Some(abs as i64)
}

fn do_boxes(rt: &'static Runtime, count: usize, mode: Mode) -> Option<i64> {
    if count == 0 || count > CAP {
        return None;
    }
    let t0 = Instant::now();
    let padded = (count + 3) & !3;
    let mut planes = [[0f32; 4]; 6];
    let mut q = [0f32; 6];
    unsafe {
        let f = rt.input.ptr as *const f32;
        for i in 0..6 {
            for j in 0..4 {
                planes[i][j] = *f.add(i * 4 + j);
            }
        }
        for i in 0..6 {
            q[i] = *f.add(28 + i);
        }
    }
    let mut guard = rt.scratch.lock().ok()?;
    let vis = &mut guard[..padded];
    let chunk = (((padded + PREC_N - 1) / PREC_N) + 3) & !3;
    let base = rt.input.ptr as usize;
    rt.prec.install(|| {
        vis.par_chunks_mut(chunk).enumerate().for_each(|(ci, out)| {
            let _b = Busy::new(&rt.doms[PREC]);
            unsafe { kernel(base as *const f32, mode, &planes, &q, ci * chunk, out) };
        });
    });
    let res = publish_mask(rt, count, &vis[..count])?;
    if mode == Mode::Frustum {
        let visible = vis[..count].iter().filter(|v| **v != 0).count() as u64;
        rt.neon_tested.fetch_add(count as u64, Ordering::Relaxed);
        rt.neon_culled.fetch_add(count as u64 - visible, Ordering::Relaxed);
        rt.last_cull_us.store(t0.elapsed().as_micros() as u64, Ordering::Relaxed);
    }
    Some(res)
}

// ---------------------------------------------------------------------------
// Aux-buffer helpers
// ---------------------------------------------------------------------------

fn aux_io(
    rt: &Runtime,
    in_off: usize,
    in_len: usize,
    out_off: usize,
    out_len: usize,
) -> Option<(&[u8], &mut [u8])> {
    let end_in = in_off.checked_add(in_len)?;
    let end_out = out_off.checked_add(out_len)?;
    if in_len == 0 || out_len == 0 || end_in > rt.aux.len || end_out > rt.aux.len {
        return None;
    }
    if in_off < end_out && out_off < end_in {
        return None; // regions overlap
    }
    if in_off % 16 != 0 || out_off % 16 != 0 {
        return None;
    }
    unsafe {
        Some((
            slice::from_raw_parts(rt.aux.ptr.add(in_off), in_len),
            slice::from_raw_parts_mut(rt.aux.ptr.add(out_off), out_len),
        ))
    }
}

unsafe fn as_f32(b: &[u8]) -> &[f32] {
    slice::from_raw_parts(b.as_ptr() as *const f32, b.len() / 4)
}
unsafe fn as_u32(b: &[u8]) -> &[u32] {
    slice::from_raw_parts(b.as_ptr() as *const u32, b.len() / 4)
}
unsafe fn as_f32_mut(b: &mut [u8]) -> &mut [f32] {
    slice::from_raw_parts_mut(b.as_mut_ptr() as *mut f32, b.len() / 4)
}
unsafe fn as_u32_mut(b: &mut [u8]) -> &mut [u32] {
    slice::from_raw_parts_mut(b.as_mut_ptr() as *mut u32, b.len() / 4)
}

fn active_of(rt: &Runtime, dom: usize) -> usize {
    rt.doms[dom].active.load(Ordering::Relaxed).clamp(1, rt.doms[dom].max)
}

// ---------------------------------------------------------------------------
// Efficiency domain: entity LOD tick intervals, 3D sound occlusion
// ---------------------------------------------------------------------------

/// in: count f32 distances; out: count u8 tick intervals (1, 2, 4, 8). Returns throttled count.
fn k_lod(rt: &'static Runtime, job: &Job) -> Option<i64> {
    let n = job.count;
    if n == 0 || n > (1 << 20) {
        return None;
    }
    let (inp, out) = aux_io(rt, job.in_off, n * 4, job.out_off, n)?;
    let dist = unsafe { as_f32(inp) };
    let chunk = (n + active_of(rt, EFF) - 1) / active_of(rt, EFF);
    let throttled = AtomicU64::new(0);
    rt.eff.install(|| {
        out.par_chunks_mut(chunk)
            .zip(dist.par_chunks(chunk))
            .for_each(|(o, d)| {
                let _b = Busy::new(&rt.doms[EFF]);
                let mut t = 0u64;
                for (slot, &dd) in o.iter_mut().zip(d.iter()) {
                    let iv = if dd.is_nan() || dd < 32.0 {
                        1
                    } else if dd < 64.0 {
                        2
                    } else if dd < 128.0 {
                        4
                    } else {
                        8
                    };
                    *slot = iv;
                    if iv > 1 {
                        t += 1;
                    }
                }
                throttled.fetch_add(t, Ordering::Relaxed);
            });
    });
    Some(throttled.load(Ordering::Relaxed) as i64)
}

/// in layout: [listener xyz f32][grid origin xyz f32][u8 flags dx*dy*dz padded to 4][sources xyz f32 * count]
/// p0..p2 = grid dims in 16-block sections. flags: 0 air, 1 partial, 2 solid. out: count f32 in [0,1].
/// Sources within 16 blocks skip the math entirely.
fn k_sound(rt: &'static Runtime, job: &Job) -> Option<i64> {
    let n = job.count;
    let (dx, dy, dz) = (job.p[0] as usize, job.p[1] as usize, job.p[2] as usize);
    if n == 0 || n > 65536 || dx == 0 || dy == 0 || dz == 0 || dx > 64 || dy > 64 || dz > 64 {
        return None;
    }
    let cells = dx * dy * dz;
    let fl = (cells + 3) & !3;
    let in_len = 24 + fl + n * 12;
    let (inp, out) = aux_io(rt, job.in_off, in_len, job.out_off, n * 4)?;
    let hdr = unsafe { as_f32(&inp[..24]) };
    let (lx, ly, lz, ox, oy, oz) = (hdr[0], hdr[1], hdr[2], hdr[3], hdr[4], hdr[5]);
    let flags = &inp[24..24 + cells];
    let src = unsafe { as_f32(&inp[24 + fl..]) };
    let outf = unsafe { as_f32_mut(out) };
    let chunk = (n + active_of(rt, EFF) - 1) / active_of(rt, EFF);
    let occluded = AtomicU64::new(0);
    rt.eff.install(|| {
        outf.par_chunks_mut(chunk)
            .zip(src.par_chunks(chunk * 3))
            .for_each(|(o, s)| {
                let _b = Busy::new(&rt.doms[EFF]);
                let mut occ = 0u64;
                for (k, slot) in o.iter_mut().enumerate() {
                    let (vx, vy, vz) = (s[k * 3] - lx, s[k * 3 + 1] - ly, s[k * 3 + 2] - lz);
                    let dist = (vx * vx + vy * vy + vz * vz).sqrt();
                    if !(dist > 16.0) {
                        *slot = 0.0;
                        continue;
                    }
                    let steps = ((dist / 8.0).ceil() as usize).min(64);
                    let mut acc = 0.0f32;
                    for t in 1..steps {
                        let u = t as f32 / steps as f32;
                        let fx = ((lx + vx * u - ox) / 16.0).floor();
                        let fy = ((ly + vy * u - oy) / 16.0).floor();
                        let fz = ((lz + vz * u - oz) / 16.0).floor();
                        if fx < 0.0 || fy < 0.0 || fz < 0.0 {
                            continue;
                        }
                        let (ix, iy, iz) = (fx as usize, fy as usize, fz as usize);
                        if ix >= dx || iy >= dy || iz >= dz {
                            continue;
                        }
                        acc += match flags[(iy * dz + iz) * dx + ix] {
                            0 => 0.0,
                            1 => 0.08,
                            _ => 0.35,
                        };
                        if acc >= 1.0 {
                            break;
                        }
                    }
                    *slot = acc.min(1.0);
                    if *slot > 0.0 {
                        occ += 1;
                    }
                }
                occluded.fetch_add(occ, Ordering::Relaxed);
            });
    });
    Some(occluded.load(Ordering::Relaxed) as i64)
}

// ---------------------------------------------------------------------------
// Performance domain: vertex sort, light propagation, section meshing
// ---------------------------------------------------------------------------

/// in: count f32 depths; out: count u32 indices ordered far-to-near (translucency order).
fn k_vert_sort(rt: &'static Runtime, job: &Job) -> Option<i64> {
    let n = job.count;
    if n == 0 || n > (1 << 20) {
        return None;
    }
    let (inp, out) = aux_io(rt, job.in_off, n * 4, job.out_off, n * 4)?;
    let depth = unsafe { as_f32(inp) };
    let outp = unsafe { as_u32_mut(out) };
    let mut pairs: Vec<(f32, u32)> = depth.iter().enumerate().map(|(i, &d)| (d, i as u32)).collect();
    rt.perf.install(|| {
        let _b = Busy::new(&rt.doms[PERF]);
        if n < 4096 {
            pairs.sort_unstable_by(|a, b| b.0.total_cmp(&a.0).then(a.1.cmp(&b.1)));
        } else {
            pairs.par_sort_unstable_by(|a, b| b.0.total_cmp(&a.0).then(a.1.cmp(&b.1)));
        }
    });
    for (o, p) in outp.iter_mut().zip(pairs.iter()) {
        *o = p.1;
    }
    Some(n as i64)
}

/// p0..p2 = W,H,D (<=128). in: opacity u8[vol] (0 = transparent) then emission u8[vol] (0..15).
/// out: light u8[vol]. Parallel Jacobi relaxation by Z-slabs. Returns passes used.
fn k_light(rt: &'static Runtime, job: &Job) -> Option<i64> {
    let (w, h, d) = (job.p[0] as usize, job.p[1] as usize, job.p[2] as usize);
    if w == 0 || h == 0 || d == 0 || w > 128 || h > 128 || d > 128 {
        return None;
    }
    let vol = w * h * d;
    let (inp, out) = aux_io(rt, job.in_off, vol * 2, job.out_off, vol)?;
    let (opacity, emission) = inp.split_at(vol);
    let mut cur: Vec<u8> = emission.iter().map(|e| e & 15).collect();
    let mut nxt = vec![0u8; vol];
    let plane = w * h;
    let slabs = (d + active_of(rt, PERF) - 1) / active_of(rt, PERF);
    let chunk = slabs * plane;
    let mut passes = 0i64;
    rt.perf.install(|| {
        for _ in 0..15 {
            passes += 1;
            let changed = AtomicBool::new(false);
            {
                let cur_ref = &cur;
                nxt.par_chunks_mut(chunk).enumerate().for_each(|(ci, o)| {
                    let _b = Busy::new(&rt.doms[PERF]);
                    let base = ci * chunk;
                    for (li, slot) in o.iter_mut().enumerate() {
                        let idx = base + li;
                        let z = idx / plane;
                        let rem = idx % plane;
                        let y = rem / w;
                        let x = rem % w;
                        let mut best = emission[idx] & 15;
                        if opacity[idx] == 0 {
                            if x > 0 {
                                best = best.max(cur_ref[idx - 1].saturating_sub(1));
                            }
                            if x + 1 < w {
                                best = best.max(cur_ref[idx + 1].saturating_sub(1));
                            }
                            if y > 0 {
                                best = best.max(cur_ref[idx - w].saturating_sub(1));
                            }
                            if y + 1 < h {
                                best = best.max(cur_ref[idx + w].saturating_sub(1));
                            }
                            if z > 0 {
                                best = best.max(cur_ref[idx - plane].saturating_sub(1));
                            }
                            if z + 1 < d {
                                best = best.max(cur_ref[idx + plane].saturating_sub(1));
                            }
                        }
                        if best != cur_ref[idx] {
                            changed.store(true, Ordering::Relaxed);
                        }
                        *slot = best;
                    }
                });
            }
            std::mem::swap(&mut cur, &mut nxt);
            if !changed.load(Ordering::Relaxed) {
                break;
            }
        }
    });
    out.copy_from_slice(&cur);
    Some(passes)
}

fn mesh_section(s: &[u8], o: &mut [u8]) -> u32 {
    const DIRS: [(i32, i32, i32); 6] = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)];
    let mut n = 0u32;
    'outer: for y in 0..16usize {
        for z in 0..16usize {
            for x in 0..16usize {
                if s[y * 256 + z * 16 + x] == 0 {
                    continue;
                }
                for (d, (dx, dy, dz)) in DIRS.iter().enumerate() {
                    let (nx, ny, nz) = (x as i32 + dx, y as i32 + dy, z as i32 + dz);
                    let exposed = if nx < 0 || ny < 0 || nz < 0 || nx >= 16 || ny >= 16 || nz >= 16 {
                        true
                    } else {
                        s[ny as usize * 256 + nz as usize * 16 + nx as usize] == 0
                    };
                    if exposed {
                        if n as usize >= MAXF {
                            break 'outer;
                        }
                        let packed: u32 = (x as u32) | ((y as u32) << 4) | ((z as u32) << 8) | ((d as u32) << 12);
                        let at = 4 + n as usize * 4;
                        o[at..at + 4].copy_from_slice(&packed.to_ne_bytes());
                        n += 1;
                    }
                }
            }
        }
    }
    o[0..4].copy_from_slice(&n.to_ne_bytes());
    n
}

/// count = sections (<=256). in: count * 4096 opacity bytes (index y*256+z*16+x).
/// out: per section [u32 face_count][MAXF u32 faces], stride MSTRIDE. Face = x|y<<4|z<<8|dir<<12.
/// Section borders count as exposed. Returns total faces.
fn k_mesh(rt: &'static Runtime, job: &Job) -> Option<i64> {
    let n = job.count;
    if n == 0 || n > 256 {
        return None;
    }
    let (inp, out) = aux_io(rt, job.in_off, n * SEC, job.out_off, n * MSTRIDE)?;
    let min_len = (n + active_of(rt, PERF) - 1) / active_of(rt, PERF);
    let total = AtomicU64::new(0);
    rt.perf.install(|| {
        out.par_chunks_mut(MSTRIDE)
            .zip(inp.par_chunks(SEC))
            .with_min_len(min_len)
            .for_each(|(o, s)| {
                let _b = Busy::new(&rt.doms[PERF]);
                total.fetch_add(mesh_section(s, o) as u64, Ordering::Relaxed);
            });
    });
    Some(total.load(Ordering::Relaxed) as i64)
}

// ---------------------------------------------------------------------------
// Smart domain: draw-call sorter + 12.5 ms governor
// ---------------------------------------------------------------------------

/// in: count u32 state keys (shader/texture packed by Java); out: count u32 permutation (stable
/// LSD radix sort). Returns the number of distinct consecutive state groups.
fn k_draw_sort(rt: &'static Runtime, job: &Job) -> Option<i64> {
    let n = job.count;
    if n == 0 || n > (1 << 20) {
        return None;
    }
    let (inp, out) = aux_io(rt, job.in_off, n * 4, job.out_off, n * 4)?;
    let keys = unsafe { as_u32(inp) };
    let outp = unsafe { as_u32_mut(out) };
    let mut a: Vec<u32> = (0..n as u32).collect();
    let mut b = vec![0u32; n];
    for pass in 0..4 {
        let shift = pass * 8;
        let mut cnt = [0usize; 257];
        for &i in &a {
            cnt[((keys[i as usize] >> shift) & 0xFF) as usize + 1] += 1;
        }
        for k in 0..256 {
            cnt[k + 1] += cnt[k];
        }
        for &i in &a {
            let dgt = ((keys[i as usize] >> shift) & 0xFF) as usize;
            b[cnt[dgt]] = i;
            cnt[dgt] += 1;
        }
        std::mem::swap(&mut a, &mut b);
    }
    outp.copy_from_slice(&a);
    let mut groups = 1i64;
    for w in a.windows(2) {
        if keys[w[0] as usize] != keys[w[1] as usize] {
            groups += 1;
        }
    }
    Some(groups)
}

fn f64_load(a: &AtomicU64) -> f64 {
    f64::from_bits(a.load(Ordering::Relaxed))
}

fn governor_tick(rt: &'static Runtime, last_step: &mut Instant) {
    let now_ms = rt.epoch.elapsed().as_millis() as u64;
    if now_ms.saturating_sub(rt.last_mark_ms.load(Ordering::Relaxed)) > 1000 {
        return; // no frames recently (menu / paused)
    }
    let ema = f64_load(&rt.ema_us);
    if ema <= 0.0 || last_step.elapsed() < Duration::from_millis(150) {
        return;
    }
    let perf = rt.doms[PERF].active.load(Ordering::Relaxed);
    let eff = rt.doms[EFF].active.load(Ordering::Relaxed);
    if ema > FRAME_TARGET_US * 1.08 {
        // Over budget: shed background work first, then burst the Performance pool.
        if eff > 2 {
            rt.doms[EFF].active.store(eff - 1, Ordering::Relaxed);
        } else if perf < PERF_MAX {
            if perf == PERF_BASE {
                rt.burst_events.fetch_add(1, Ordering::Relaxed);
            }
            rt.doms[PERF].active.store(perf + 1, Ordering::Relaxed);
        } else if eff > 1 {
            rt.doms[EFF].active.store(eff - 1, Ordering::Relaxed);
        } else {
            return;
        }
        rt.gov_steps.fetch_add(1, Ordering::Relaxed);
        *last_step = Instant::now();
    } else if ema < FRAME_TARGET_US * 0.85 {
        // Headroom: unwind the burst, then bring background workers back.
        if perf > PERF_BASE {
            rt.doms[PERF].active.store(perf - 1, Ordering::Relaxed);
        } else if eff < EFF_N {
            rt.doms[EFF].active.store(eff + 1, Ordering::Relaxed);
        } else {
            return;
        }
        rt.gov_steps.fetch_add(1, Ordering::Relaxed);
        *last_step = Instant::now();
    }
}

fn smart_main(rt: &'static Runtime, big: u64) {
    pin_current(big);
    let mut last_step = Instant::now();
    let mut next_gov = Instant::now();
    while !rt.shutdown.load(Ordering::Relaxed) {
        while let Some(job) = rt.smart_q.pop() {
            let _b = Busy::new(&rt.doms[SMART]);
            let done = job.done.clone();
            match catch_unwind(AssertUnwindSafe(|| k_draw_sort(rt, &job))) {
                Ok(Some(v)) => done.finish(true, v),
                _ => done.finish(false, -1),
            }
        }
        let now = Instant::now();
        if now >= next_gov {
            let _b = Busy::new(&rt.doms[SMART]);
            let _ = catch_unwind(AssertUnwindSafe(|| governor_tick(rt, &mut last_step)));
            next_gov = now + Duration::from_micros(FRAME_TARGET_US as u64);
        }
        let wait = next_gov.saturating_duration_since(Instant::now());
        thread::park_timeout(wait.max(Duration::from_millis(1)));
    }
}

fn frame_mark(rt: &Runtime, ns: u64) {
    let ns = ns.min(200_000_000);
    rt.frame_ns.store(ns, Ordering::Relaxed);
    let us = ns as f64 / 1000.0;
    let e = f64_load(&rt.ema_us);
    let n = if e <= 0.0 { us } else { e * 0.9 + us * 0.1 };
    rt.ema_us.store(n.to_bits(), Ordering::Relaxed);
    rt.last_mark_ms.store(rt.epoch.elapsed().as_millis() as u64, Ordering::Relaxed);
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

/// Layout: 0-5 util permille | 6-11 tasks | 12-17 active threads | 18 neon tested | 19 neon culled
/// 20 burst active | 21 burst events | 22 active workers | 23 ema us | 24 target us | 25 ring tail
/// 26 dropped jobs | 27 last cull us | 28 governor steps | 29 neon path (1) | 30 ring seq
fn collect_stats(rt: &Runtime) -> [u64; 32] {
    let mut s = [0u64; 32];
    let now = Instant::now();
    let mut g = rt.snap.lock().unwrap_or_else(|e| e.into_inner());
    let dt = now.duration_since(g.ts).as_nanos().max(1) as u64;
    let refresh = dt >= 100_000_000;
    let mut workers = 0u64;
    for i in 0..6 {
        let busy = rt.doms[i].busy_ns.load(Ordering::Relaxed);
        let act = rt.doms[i].active.load(Ordering::Relaxed).max(1) as u64;
        if refresh {
            let d = busy.saturating_sub(g.busy[i]);
            g.util[i] = (d.saturating_mul(1000) / (dt * act)).min(1000);
            g.busy[i] = busy;
        }
        s[i] = g.util[i];
        s[6 + i] = rt.doms[i].tasks.load(Ordering::Relaxed);
        s[12 + i] = act;
        workers += act;
    }
    if refresh {
        g.ts = now;
    }
    let perf_active = rt.doms[PERF].active.load(Ordering::Relaxed);
    s[18] = rt.neon_tested.load(Ordering::Relaxed);
    s[19] = rt.neon_culled.load(Ordering::Relaxed);
    s[20] = perf_active.saturating_sub(PERF_BASE) as u64;
    s[21] = rt.burst_events.load(Ordering::Relaxed);
    s[22] = workers;
    s[23] = f64_load(&rt.ema_us) as u64;
    s[24] = FRAME_TARGET_US as u64;
    s[25] = unsafe { &*(rt.ring.ptr.add(64) as *const AtomicU64) }.load(Ordering::Relaxed);
    s[26] = rt.dropped.load(Ordering::Relaxed);
    s[27] = rt.last_cull_us.load(Ordering::Relaxed);
    s[28] = rt.gov_steps.load(Ordering::Relaxed);
    s[29] = if cfg!(target_arch = "aarch64") { 1 } else { 0 };
    s[30] = rt.ring_seq.load(Ordering::Relaxed) as u64;
    s
}

// ---------------------------------------------------------------------------
// JNI surface: io.infinityosus.natives.OsusNative
// ---------------------------------------------------------------------------

#[no_mangle]
pub extern "system" fn Java_io_infinityosus_natives_OsusNative_nativeInit<'l>(
    _env: JNIEnv<'l>,
    _class: JClass<'l>,
) -> jboolean {
    match catch_unwind(init_runtime) {
        Ok(true) => JNI_TRUE,
        _ => JNI_FALSE,
    }
}

#[no_mangle]
pub extern "system" fn Java_io_infinityosus_natives_OsusNative_nativeHasNeon<'l>(
    _env: JNIEnv<'l>,
    _class: JClass<'l>,
) -> jboolean {
    if cfg!(target_arch = "aarch64") {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

/// which: 0 = input, 1 = ring, 2 = aux. Returns a direct ByteBuffer over native memory (zero-copy).
#[no_mangle]
pub extern "system" fn Java_io_infinityosus_natives_OsusNative_nativeBuffer<'l>(
    mut env: JNIEnv<'l>,
    _class: JClass<'l>,
    which: jint,
) -> jobject {
    let r = catch_unwind(AssertUnwindSafe(|| {
        let rt = RT.get()?;
        let b = match which {
            0 => &rt.input,
            1 => &rt.ring,
            2 => &rt.aux,
            _ => return None,
        };
        #[allow(unused_unsafe)]
        let buf = unsafe { env.new_direct_byte_buffer(b.ptr, b.len) }.ok()?;
        Some(buf.as_raw())
    }));
    match r {
        Ok(Some(p)) => p,
        _ => std::ptr::null_mut(),
    }
}

/// Submits a job to the Osus router and blocks (<= 60 ms) for the result. Returns -1 on failure.
#[no_mangle]
pub extern "system" fn Java_io_infinityosus_natives_OsusNative_nativeSubmit<'l>(
    _env: JNIEnv<'l>,
    _class: JClass<'l>,
    kind: jint,
    count: jint,
    p0: jint,
    p1: jint,
    p2: jint,
    p3: jint,
    in_off: jlong,
    out_off: jlong,
) -> jlong {
    let k = match Kind::from_i32(kind) {
        Some(k) => k,
        None => return -1,
    };
    if count < 0 || in_off < 0 || out_off < 0 {
        return -1;
    }
    match catch_unwind(AssertUnwindSafe(|| {
        submit(
            k,
            count as usize,
            [p0 as u32, p1 as u32, p2 as u32, p3 as u32],
            in_off as usize,
            out_off as usize,
        )
    })) {
        Ok(v) => v,
        Err(_) => -1,
    }
}

#[no_mangle]
pub extern "system" fn Java_io_infinityosus_natives_OsusNative_nativeFrameMark<'l>(
    _env: JNIEnv<'l>,
    _class: JClass<'l>,
    frame_ns: jlong,
) {
    if frame_ns <= 0 {
        return;
    }
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if let Some(rt) = RT.get() {
            frame_mark(rt, frame_ns as u64);
        }
    }));
}

#[no_mangle]
pub extern "system" fn Java_io_infinityosus_natives_OsusNative_nativeGetStats<'l>(
    mut env: JNIEnv<'l>,
    _class: JClass<'l>,
    out: JLongArray<'l>,
) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if let Some(rt) = RT.get() {
            let s = collect_stats(rt);
            let v: Vec<i64> = s.iter().map(|&x| x as i64).collect();
            let len = env.get_array_length(&out).unwrap_or(0) as usize;
            let n = len.min(v.len());
            let _ = env.set_long_array_region(&out, 0, &v[..n]);
        }
    }));
}

#[no_mangle]
pub extern "system" fn Java_io_infinityosus_natives_OsusNative_nativeShutdown<'l>(
    _env: JNIEnv<'l>,
    _class: JClass<'l>,
) {
    if let Some(rt) = RT.get() {
        rt.shutdown.store(true, Ordering::Relaxed);
        if let Some(t) = rt.router_thread.get() {
            t.unpark();
        }
        if let Some(t) = rt.smart_thread.get() {
            t.unpark();
        }
    }
}
